import _ from 'lodash'

export const updateIsLogin = (payload) => {
  return (dispatch) => {
    dispatch({
      type: 'updateIsLogin',
      payload
    })
  }
}

export const MAHESH = (payload) => {
  return (dispatch) => {
    dispatch({
      type: 'TESTING',
      payload
    })
  }
}
// export const updateEnterCity = (payload) => {
//   return (dispatch) => {
//     dispatch({
//       type: 'updateEnterCity',
//       payload
//     })
//   }
// }
// export const listData = (payload) => {
//   return (dispatch) => {
//     dispatch({
//       type: 'listData',
//       payload
//     })
//   }
// }

// export const AddItem = (payload) => {
//   return (dispatch) => {
//     dispatch({
//       type: 'AddItem',
//       payload
//     })
//   }
 
