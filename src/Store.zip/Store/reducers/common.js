const initialState = {
  isLogin: false,
  updateEnter_City:'',
  list_Data:[],
  Add_cart:[],
  TESTINGDATA:''
}

export default function common(state = initialState, action = {}) {
  switch (action.type) {

    case 'updateIsLogin': {
      return {
        ...state,
        isLogin: action.payload
      }
    }
    case 'TESTING': {
      return {
        ...state,
        TESTINGDATA: action.payload,
      

      }
    }
    // case 'updateEnterCity': {
    //   return {
    //     ...state,
    //     updateEnter_City: action.payload
    //   }
    // }
    // case 'listData': {
    //   return {
    //     ...state,
    //     list_Data: action.payload
    //   }
    // }
    // case 'AddItem': {
    //   return {
    //     ...state,
    //     Add_cart: action.payload
    //   }
    // }
    default:
      return state
  }
}
